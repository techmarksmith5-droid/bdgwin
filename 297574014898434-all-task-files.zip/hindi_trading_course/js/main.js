// Enhanced interactions for the landing page

document.addEventListener('DOMContentLoaded', function() {
    
    // Add loading animation to CTA buttons
    const ctaButtons = document.querySelectorAll('.cta-button');
    
    ctaButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Add a subtle loading effect
            const originalText = this.textContent;
            this.style.transform = 'scale(0.95)';
            
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
            
            // Track button clicks (for analytics)
            console.log('CTA Button clicked:', originalText);
        });
    });
    
    // FAQ Accordion Functionality
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        question.addEventListener('click', function() {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                    const otherAnswer = otherItem.querySelector('.faq-answer');
                    otherAnswer.style.maxHeight = '0px';
                }
            });
            
            // Toggle current FAQ item
            if (isActive) {
                item.classList.remove('active');
                answer.style.maxHeight = '0px';
            } else {
                item.classList.add('active');
                answer.style.maxHeight = answer.scrollHeight + 'px';
            }
        });
    });
    
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.why-item, .highlight-item, .testimonial-chat, .who-item, .faq-item');
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
    
    // Special animation for learn items
    const learnItemsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const learnItems = entry.target.querySelectorAll('.learn-item');
                learnItems.forEach((item, index) => {
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'translateX(0)';
                    }, index * 200);
                });
            }
        });
    }, { threshold: 0.2 });
    
    const learnSection = document.querySelector('.learn-section');
    if (learnSection) {
        learnItemsObserver.observe(learnSection);
    }
    
    // Add stagger animation for grid items
    const whyItems = document.querySelectorAll('.why-item');
    whyItems.forEach((item, index) => {
        item.style.transitionDelay = `${index * 0.1}s`;
    });
    
    const highlightItems = document.querySelectorAll('.highlight-item');
    highlightItems.forEach((item, index) => {
        item.style.transitionDelay = `${index * 0.1}s`;
    });
    
    // Smooth scroll for any internal links (if added later)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add hover effects to testimonial bubbles
    const testimonialBubbles = document.querySelectorAll('.message-bubble');
    testimonialBubbles.forEach(bubble => {
        bubble.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.02)';
            this.style.transition = 'transform 0.2s ease';
        });
        
        bubble.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Course Preview Video Interaction (Enhanced Vimeo)
    const videoWrapper = document.querySelector('.video-wrapper');
    const vimeoIframe = document.querySelector('.vimeo-iframe');
    
    if (videoWrapper && vimeoIframe) {
        // Device detection
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 767;
        
        console.log('Enhanced Vimeo player initialized - Mobile:', isMobile);
        
        // Desktop hover effects
        if (!isMobile) {
            videoWrapper.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.02)';
                this.style.borderColor = 'rgba(0, 255, 144, 0.4)';
            });
            
            videoWrapper.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
                this.style.borderColor = 'rgba(0, 255, 144, 0.2)';
            });
        }
        
        // Mobile touch interactions
        if (isMobile) {
            videoWrapper.addEventListener('touchstart', function(e) {
                this.style.transform = 'scale(0.98)';
                this.style.borderColor = 'rgba(0, 255, 144, 0.4)';
            }, { passive: true });
            
            videoWrapper.addEventListener('touchend', function(e) {
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                    this.style.borderColor = 'rgba(0, 255, 144, 0.2)';
                }, 150);
            }, { passive: true });
        }
        
        // Initialize Vimeo Player API
        function initVimeoPlayer() {
            try {
                if (typeof Vimeo !== 'undefined') {
                    const player = new Vimeo.Player(vimeoIframe);
                    
                    player.on('loaded', function() {
                        console.log('Enhanced Vimeo video loaded successfully');
                        videoWrapper.style.opacity = '1';
                        videoWrapper.classList.remove('pulsing');
                    });
                    
                    player.on('play', function() {
                        console.log('Video started playing');
                        videoWrapper.classList.remove('pulsing');
                        videoWrapper.style.borderColor = 'rgba(0, 255, 144, 0.3)';
                    });
                    
                    player.on('pause', function() {
                        console.log('Video paused');
                        videoWrapper.classList.add('pulsing');
                        videoWrapper.style.borderColor = 'rgba(0, 255, 144, 0.2)';
                    });
                    
                    player.on('ended', function() {
                        console.log('Video ended - will loop automatically');
                    });
                    
                    player.on('bufferstart', function() {
                        videoWrapper.style.opacity = '0.8';
                    });
                    
                    player.on('bufferend', function() {
                        videoWrapper.style.opacity = '1';
                    });
                    
                    player.on('error', function(error) {
                        console.error('Vimeo player error:', error);
                        videoWrapper.classList.add('pulsing');
                    });
                    
                    // Track video progress
                    player.on('timeupdate', function(data) {
                        if (data.seconds > 0.5) {
                            videoWrapper.classList.remove('pulsing');
                        }
                    });
                    
                    return player;
                } else {
                    console.log('Vimeo API not yet loaded, will retry');
                    return null;
                }
            } catch (error) {
                console.error('Failed to initialize Vimeo player:', error);
                return null;
            }
        }
        
        // Try to initialize player
        let player = initVimeoPlayer();
        
        // Retry mechanism for Vimeo API loading
        if (!player) {
            let retryCount = 0;
            const maxRetries = 3;
            
            const retryInit = setInterval(() => {
                retryCount++;
                console.log(`Retrying Vimeo initialization (${retryCount}/${maxRetries})`);
                
                player = initVimeoPlayer();
                
                if (player || retryCount >= maxRetries) {
                    clearInterval(retryInit);
                    if (!player) {
                        console.log('Vimeo API retry limit reached, video should still work with native controls');
                        videoWrapper.style.opacity = '1';
                        videoWrapper.classList.remove('pulsing');
                    }
                }
            }, 1500);
        }
        
        // Orientation change handling
        window.addEventListener('orientationchange', function() {
            setTimeout(function() {
                // Force video container recalculation
                const videoContainer = videoWrapper.querySelector('.preview-video > div');
                if (videoContainer) {
                    videoContainer.style.height = '0';
                    videoContainer.style.paddingBottom = '177.77%';
                }
            }, 200);
        });
        
        // Initial loading state
        videoWrapper.style.opacity = '0.8';
        videoWrapper.classList.add('pulsing');
        
        // Progressive loading
        setTimeout(function() {
            videoWrapper.style.opacity = '1';
        }, 1000);
        
        // Auto-remove pulsing after reasonable time
        setTimeout(function() {
            if (videoWrapper.classList.contains('pulsing')) {
                videoWrapper.classList.remove('pulsing');
                console.log('Auto-removed pulsing - video should be ready');
            }
        }, 3000);
    }
    
    // Enhanced Who Section Hover Effects
    const whoItems = document.querySelectorAll('.who-item');
    whoItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Learn Items Interactive Effects
    const learnItems = document.querySelectorAll('.learn-item');
    learnItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.background = 'rgba(0, 255, 144, 0.08)';
            this.style.borderLeftWidth = '6px';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.background = 'rgba(255, 255, 255, 0.03)';
            this.style.borderLeftWidth = '4px';
        });
    });
    
    // Add floating animation to hero icons
    const heroEmojis = document.querySelectorAll('.hero-title, .hero-subtitle');
    heroEmojis.forEach(element => {
        element.addEventListener('mouseover', function() {
            this.style.animation = 'none';
            this.style.transform = 'translateY(-5px)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        element.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Performance optimization: Preload WhatsApp link
    const whatsappLink = 'https://chat.whatsapp.com/L8RzWQjtZ8dETEEBSQketw?mode=ac_t';
    const link = document.createElement('link');
    link.rel = 'preconnect';
    link.href = 'https://chat.whatsapp.com';
    document.head.appendChild(link);
    
    // Enhanced parallax effect for multiple sections
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        
        // Hero parallax
        const hero = document.querySelector('.hero-section');
        if (hero && scrolled < window.innerHeight) {
            const rate = scrolled * -0.3;
            hero.style.transform = `translateY(${rate}px)`;
        }
        
        // Floating shapes parallax
        const shapes = document.querySelectorAll('.floating-shape');
        shapes.forEach((shape, index) => {
            const rate = (scrolled * (0.1 + index * 0.05));
            shape.style.transform = `translateY(${rate}px) rotate(${rate * 0.5}deg)`;
        });
        
        // Add scroll-triggered animations for glassmorphism effects
        const glassmorphismElements = document.querySelectorAll('.glassmorphism');
        glassmorphismElements.forEach(element => {
            const elementTop = element.offsetTop;
            const elementHeight = element.offsetHeight;
            const viewportHeight = window.innerHeight;
            
            if (scrolled + viewportHeight > elementTop && scrolled < elementTop + elementHeight) {
                element.style.background = 'rgba(255, 255, 255, 0.08)';
                element.style.backdropFilter = 'blur(25px)';
            } else {
                element.style.background = 'rgba(255, 255, 255, 0.05)';
                element.style.backdropFilter = 'blur(20px)';
            }
        });
    });
    
    // Add loading state management
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
        
        // Trigger initial animations
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            heroContent.style.opacity = '1';
            heroContent.style.transform = 'translateY(0)';
        }
    });
    
    // Error handling for external links
    ctaButtons.forEach(button => {
        button.addEventListener('error', function() {
            console.error('Failed to load WhatsApp link');
            // Could show a fallback message here
        });
    });
    
    // Add touch feedback for mobile devices
    if ('ontouchstart' in window) {
        document.querySelectorAll('.cta-button, .why-item, .highlight-item, .who-item, .learn-item, .faq-question').forEach(element => {
            element.addEventListener('touchstart', function() {
                this.style.opacity = '0.8';
            });
            
            element.addEventListener('touchend', function() {
                this.style.opacity = '1';
            });
        });
    }
    
    // Automatic FAQ highlight on scroll
    const autoHighlightFAQ = () => {
        const faqSection = document.querySelector('.faq-section');
        if (faqSection) {
            const rect = faqSection.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                // Highlight first FAQ item if none are active
                const activeFAQ = document.querySelector('.faq-item.active');
                if (!activeFAQ) {
                    const firstFAQ = document.querySelector('.faq-item');
                    if (firstFAQ) {
                        setTimeout(() => {
                            firstFAQ.querySelector('.faq-question').click();
                        }, 1000);
                    }
                }
            }
        }
    };
    
    // Add scroll listener for auto FAQ highlight
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(autoHighlightFAQ, 500);
    });
    
    // Logo loading animation
    const mainLogo = document.querySelector('.main-logo');
    if (mainLogo) {
        mainLogo.addEventListener('load', function() {
            this.style.opacity = '1';
            this.style.transform = 'translateY(0) scale(1)';
        });
        
        // Set initial state
        mainLogo.style.opacity = '0';
        mainLogo.style.transform = 'translateY(-20px) scale(0.8)';
        mainLogo.style.transition = 'all 0.8s ease-out';
    }
    
    console.log('Hindi Trading Course landing page loaded successfully! 🎯✨');
});